class SavingAccount
{
    private:
    double SavingsBalance;
    static double annualInterestRate;
    
    public:
    SavingAccount(double poupanca);
    double calculateMonthlyInterest();
    static void modifyInterestRate(double novaTaxa);
    void imprimirSaldos();
    void imprimirTaxa();
};
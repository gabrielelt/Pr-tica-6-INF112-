#include<iostream>
#include"SavingAccount.h"

int main()
{
    double taxaAnual = 0.04;
    SavingAccount::modifyInterestRate (taxaAnual);

    SavingAccount saver1 = SavingAccount(2000);
    SavingAccount saver2 = SavingAccount(3000);

    std::cout << "Arrecadacao mensal com taxa de juros em 4%: \nSaver 1: " << saver1.calculateMonthlyInterest() << std::endl;
    std::cout << "Saver 2: " << saver2.calculateMonthlyInterest() << "\n\n";
    

    //std::cin >> taxaAnual;
    taxaAnual = 0.03;
    SavingAccount::modifyInterestRate(taxaAnual);

    std::cout <<"Arrecadacao mensal, acumulada, com taxa de juros em 3%: \nSaver 1: " <<  saver1.calculateMonthlyInterest() << std::endl;
    std::cout << "Saver2: " << saver2.calculateMonthlyInterest() << "\n\n";

    std::cout << "Saldo atual do Saver 1, apos acumulacao de um mes a taxa de 4% e um mes a 3%" << std::endl;
    saver1.imprimirSaldos();
    std::cout << "Saldo atual do Saver 2, apos acumulacao de um mes a taxa de 4% e um mes a 3%" << std::endl;
    saver2.imprimirSaldos();

}
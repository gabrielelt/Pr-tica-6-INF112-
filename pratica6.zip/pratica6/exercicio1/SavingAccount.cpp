#include"SavingAccount.h"
#include<iostream>

double SavingAccount::annualInterestRate = 0.0;

SavingAccount::SavingAccount(double _SavingBalance)
{
    this->SavingsBalance = _SavingBalance;

}

double SavingAccount::calculateMonthlyInterest()
{
    double monthlyInterest;
    monthlyInterest = (SavingsBalance*annualInterestRate)/12;
    SavingsBalance += (SavingsBalance*annualInterestRate)/12;
    return monthlyInterest;
}

void SavingAccount::modifyInterestRate(double novaTaxa)
{
    annualInterestRate = novaTaxa;
}

void SavingAccount::imprimirSaldos()
{
    std::cout << "O saldo atual da poupanca e: \n$" << SavingsBalance << "\n\n";
}

void SavingAccount::imprimirTaxa()
{
    std::cout << "O atual valor da taxa de juros e: \n" << annualInterestRate << "%" << "\n\n";
}
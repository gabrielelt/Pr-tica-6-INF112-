#include<iostream>
#include"Package.h"
#include"OverNightPackage.h"

OverNightPackage::OverNightPackage(std::string nome, std::string endereco, double peso, double custoQuilo, double taxa) : Package(nome, endereco, peso, custoQuilo), _taxaAdicionalNoturna(taxa)
{

}

OverNightPackage::~OverNightPackage()
{

}

double OverNightPackage::calculateCost() 
{
    double taxaAdicional = (_peso)*(_taxaAdicionalNoturna);
    return Package::calculateCost() + taxaAdicional;
}
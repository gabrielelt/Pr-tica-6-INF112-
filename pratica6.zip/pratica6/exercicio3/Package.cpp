#include<iostream>
#include"Package.h"
//método construtor da classe Package
Package::Package(std::string nome, std::string endereco, double peso, double custoQuilo) : _nome(nome), _endereco(endereco)
{
    //verifica se o peso é positivo
    while(peso < 0 )
    {
        std::cout << "Peso inválido, digite um valor positivo para continuar!!!" << std::endl;
        std::cin >> peso;
    }
    _peso = peso;

    //verifica se o custo/kg é posivito
    while(peso < 0 )
    {
        std::cout << "Valor de custo por quilo inválido, digite um valor positivo para continuar!!!" << std::endl;
        std::cin >> custoQuilo;
    }
    _custoQuilo = custoQuilo;
}
//método destrutor da classe Package
Package::~Package()
{

}

double Package::calculateCost()
{
    return _custoQuilo*_peso;
}
#ifndef INF112_PACKAGE_H
#define INF112_PACKAGE_H

#include<iostream>


class Package
{
    //utilizei o protected, para que as classes filhas tivessem acesso aos membros de dados dessa classe
    protected:
        const std::string _nome;
        const std::string _endereco ;
        
        //Respresentei peso e custo/kg como double, já que, no mundo real eles são representados pelos numeros reais positivos
        double _peso;
        double _custoQuilo;
    public:
        Package(std::string nome, std::string endereco, double peso, double custoQuilo);
        ~Package();
        virtual double calculateCost();

};
#endif
#ifndef INF112_OVERNIGHTPACKAGE_H   
#define INF112_OVERNIGHTPACKAGE_H

#include<iostream>
#include"Package.h"

class OverNightPackage : Package
{
    private:
        double _taxaAdicionalNoturna;
    public:
        OverNightPackage(std::string nome, std::string endereco, double peso, double custoQuilo, double taxaAdicionalNoturna);
        ~OverNightPackage();
        virtual double calculateCost() override;
};
#endif
#ifndef INF112_TWODAYPACKAGE_H
#define INF112_TWODAYPACKAGE_H

#include"Package.h"
#include<iostream>

class TwoDayPackage : Package
{
    private:
        double _taxa;
    public:
        TwoDayPackage(std::string nome, std::string endereco, double peso, double custoQuilo, double taxa);
        ~TwoDayPackage();
        virtual double calculateCost() override;
};

#endif
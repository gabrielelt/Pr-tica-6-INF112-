#include<iostream>
#include"TwoDayPackage.h"

//Criação do método construtor
TwoDayPackage::TwoDayPackage(std::string nome, std::string endereco, double peso, double custoQuilo, double taxa) : Package(nome, endereco, peso, custoQuilo), _taxa(taxa)
{

}

//Criação do método destrutor
TwoDayPackage::~TwoDayPackage()
{

}

//override da função membro calculateCost da classe Package
double TwoDayPackage::calculateCost()
{
    return Package::calculateCost() + _taxa;
}


//turma.h
#ifndef INF112_TURMA_H
#define INF112_TURMA_H

#include<iostream>
#include<vector>
//#include"Estudante.h"

class Estudante;

class Turma
{
    private:
        const std::string _codigo;
        const int _ano;
        std::vector<Estudante> alunos;
        int numeroAlunos = 0;

    public:
        Turma(std::string codigo, int ano);
        std::string getCodigo() const;
        int getAno() const;
        void adicionarAlunos(Estudante estudante);
        void imprimirTurma();
        void imprimirAlunosTurma();
};
#endif
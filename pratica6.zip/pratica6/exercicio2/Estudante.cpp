#include<iostream>
#include"Estudante.h"
#include"Pessoa.h"
#include"Turma.h"

Estudante::Estudante(std::string nome, int matricula, Turma turma) : Pessoa(nome), _matricula(matricula), turmas(turma)
{
}

std::string Estudante::defina_meu_tipo() const
{
    return "Sou um estudante";
}

std::string Estudante::getNomeEstudante() const
{
    return getNome();
}

 int Estudante::getMatricula() const
 {
    return _matricula;
 }
 
 std::string Estudante::getCodigoTurma() const
 {
    return turmas.getCodigo();
 }

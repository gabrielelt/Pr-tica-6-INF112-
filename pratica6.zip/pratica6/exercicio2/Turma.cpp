//turma.cpp
#include<iostream>
#include"Estudante.h"
#include"Turma.h"

Turma::Turma(std::string codigo, int ano) : _codigo(codigo), _ano(ano)
{
}

std::string Turma::getCodigo() const
{
    return _codigo;
}

int Turma::getAno() const
{
    return _ano;
}

void Turma::adicionarAlunos(Estudante estudante)
{
    alunos.push_back(estudante);
    numeroAlunos++;
    std::cout << std::endl;
}

void Turma::imprimirTurma()
{
    std::cout << "Codigo da turma: " << _codigo << "\nAno da turma avaliada: " << _ano << "\n \n";
}

void Turma::imprimirAlunosTurma()
    {
        for (int i = 0; i < numeroAlunos; i++)
        {
            std::cout << "Nome do aluno: " << alunos[i].getNomeEstudante() << " Matricula: " << alunos[i].getMatricula() << "\n \n";

        }
        
    }
    

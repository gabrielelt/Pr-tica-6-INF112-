//estudante.h
#ifndef INF112_ESTUDANTE_H
#define INF112_ESTUDANTE_H

#include"Pessoa.h"
#include"Turma.h"

class Estudante : public Pessoa
{
    private:
        const int _matricula;
        Turma& turmas;
    
    public:
        Estudante(std::string nome, int matricula, Turma turma);
        std::string getNomeEstudante() const;
        int getMatricula() const;
        std::string getCodigoTurma() const;
        virtual std::string defina_meu_tipo() const override;
};
#endif
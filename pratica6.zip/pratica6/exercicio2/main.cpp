#include<iostream>
#include<vector>
#include"Pessoa.h"
#include"Estudante.h"
#include"Turma.h"

int main()
{
    
    Pessoa pessoa (" Julio Reis .") ;
    Turma INF112("INF112", 2023);
    Estudante estudante1 (" Jane Doe", 20180101, INF112);
    std::cout << "Turma do estudante: " << estudante1.getCodigoTurma() << std::endl;
    
    std :: cout << "A pessoa eh: " << pessoa.defina_meu_tipo () << std :: endl ;
    std :: cout << "O estudante eh: " << estudante1.defina_meu_tipo () << "\n \n" ;
   
    INF112.adicionarAlunos(estudante1);
   
    int quantidade;
    std::cout << "Digite a quantidade de alunos que deseja adicionar à turma, 0 para sair: " << std::endl;
    std::cin >> quantidade;
 
    for (int i = 0; i < quantidade; i++)
    {
        std::string nome;
        int matricula;

        std::cout << "Digite o nome do aluno " << i + 2 << ": ";
        std::cin.ignore();
        std::getline(std::cin, nome);

        std::cout << "Agora digite sua matrícula: ";
        std::cin >> matricula;

        Estudante estudante(nome, matricula, INF112);
        INF112.adicionarAlunos(estudante);
    }
    std::cout << "\n";
    INF112.imprimirTurma();
    INF112.imprimirAlunosTurma();
    /*f ( pessoa ) ;
    f ( estudante ) ;
    */
}